#include <stdio.h>

int main(void)
{
    printf("%d\n", 20);
    return (0);
}
