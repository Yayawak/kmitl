#include <stdio.h>

int main(void)
{
    printf("%s\n", 30);
    return (0);
}

