#include <stdio.h>

int main(void)
{
    printf("%d\n", 30);
    return (0);
}
