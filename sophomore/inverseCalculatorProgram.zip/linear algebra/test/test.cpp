#include <iostream>
// using namespace std;

int main(void)
{
    // int[] a{1,2,3,4,5,6};
    int a[5];

    std::cout << sizeof(char) << "\n";
    std::cout << sizeof(int) << '\n';
    std::cout << sizeof(a) << '\n';
    return (0);
}
