#include "../include/linalg.h"

bool isSquare(Mat *m)
{
    return (m->col == m->row);
}
